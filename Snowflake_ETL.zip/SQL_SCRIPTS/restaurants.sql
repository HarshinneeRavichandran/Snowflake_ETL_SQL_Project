use database PRJ2;
use schema bronze_layer;

create  or replace table restaurants(
     restaurant_id varchar,
    id varchar,
    name varchar,
    city varchar,
    rating varchar,
    rating_count varchar,
    cost varchar,
    cuisine varchar,
    lic_no varchar,
    link varchar,
    address varchar,
    menu varchar
);

CREATE or replace FILE FORMAT MY_CSV_FORMAT
TYPE = 'CSV'
FIELD_DELIMITER = ',' 
FIELD_OPTIONALLY_ENCLOSED_BY = '"'
COMPRESSION = 'AUTO'
skip_header = 1
error_on_column_count_mismatch=false;


create or replace stage restaurants_stage
FILE_FORMAT =  (FORMAT_NAME = PRJ2.BRONZE_LAYER.MY_CSV_FORMAT);

create or replace pipe restaurants_ingest_pipe
as 
    copy into PRJ2.BRONZE_LAYER.restaurants
    from @PRJ2.BRONZE_LAYER.restaurants_STAGE
    FILE_FORMAT =  (FORMAT_NAME = 'PRJ2.BRONZE_LAYER.MY_CSV_FORMAT');


create or replace stream  restaurants_stream_bronze on table restaurants
append_only = true;-- show_initial_rows = true;

select count(*) from PRJ2.BRONZE_LAYER.restaurants; ---148541
select count(*) from PRJ2.BRONZE_LAYER.restaurants; ---148546

select system$pipe_status('PRJ2.BRONZE_LAYER.restaurants_INGEST_PIPE'); ---checks status 
call system$pipe_force_resume('PRJ2.BRONZE_LAYER.restaurants_INGEST_PIPE'); --- only loaded the newly added files from stage 
alter pipe PRJ2.BRONZE_LAYER.restaurants_INGEST_PIPE refresh;

SELECT * FROM snowflake.account_usage.copy_history
WHERE table_name = 'restaurants' and TABLE_CATALOG_NAME = 'PRJ2'
LIMIT 10;

select * from PRJ2.BRONZE_LAYER.restaurants_STREAM_BRONZE;

-----------------------------------------------------------------------------

---silver layer 


use schema PRJ2.silver_layer;

create or replace table silver_restaurants(
    id integer,
    name varchar,
    city varchar,
    rating float,
    rating_count varchar,
    cost varchar,
    cuisine varchar,
    lic_no varchar,
    link varchar,
    address varchar,
    menu varchar
) ;


 CREATE OR REPLACE TASK PRJ2.silver_layer.restaurants_curated_task
WAREHOUSE = COMPUTE_WH
SCHEDULE = '1 MINUTE'
AS
MERGE INTO PRJ2.silver_layer.silver_restaurants AS sr
USING (
  SELECT 
    id,
    name,
    city,
    CASE WHEN rating = '--' THEN '0.0' ELSE rating END AS rating,
    rating_count,
    cost,
    cuisine,
    CASE WHEN lic_no = 'license' THEN '00000000000000' ELSE lic_no END AS lic_no,
    link,
    address,
    menu
  FROM PRJ2.bronze_layer.restaurants_stream_bronze
) AS rb
ON rb.id = sr.id
WHEN MATCHED THEN
  UPDATE SET   
    sr.id = rb.id,
    sr.name = rb.name,
    sr.city = rb.city,
    sr.rating = rb.rating,
    sr.rating_count = rb.rating_count,
    sr.cost = rb.cost,
    sr.cuisine = rb.cuisine,
    sr.lic_no = rb.lic_no,
    sr.link = rb.link,
    sr.address = rb.address,
    sr.menu = rb.menu 
WHEN NOT MATCHED THEN
  INSERT (id, name, city, rating, rating_count, cost, cuisine, lic_no, link, address, menu) 
  VALUES (rb.id, rb.name, rb.city, rb.rating, rb.rating_count, rb.cost, rb.cuisine, rb.lic_no, rb.link, rb.address, rb.menu);

--activate the task
ALTER TASK restaurants_curated_task RESUME;

select count(*) from PRJ2.SILVER_LAYER.SILVER_restaurants; --- 148541
select count(*) from PRJ2.SILVER_LAYER.SILVER_restaurants; --- 148546
select * from  PRJ2.bronze_layer.restaurants_stream_bronze;
select * from PRJ2.BRONZE_LAYER.RESTAURANTS;

SELECT * 
  FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
  where database_name = 'PRJ2' and name = 'RESTAURANTS_CURATED_TASK'
  ORDER BY SCHEDULED_TIME
  ;

----------------------------------------------------------

use schema PRJ2.silver_layer;

create or replace stream  restaurants_stream_silver on table SILVER_RESTAURANTS
append_only = true;-- show_initial_rows = true;


use schema PRJ2.gold_layer;

select * from PRJ2.gold_layer.restaurants_dim;
select * from  PRJ2.silver_layer.restaurants_stream_silver;

 CREATE OR REPLACE TASK PRJ2.gold_layer.restaurants_curated_task_gold
WAREHOUSE = COMPUTE_WH
SCHEDULE = '1 MINUTE'
AS
MERGE INTO PRJ2.gold_layer.restaurants_dim AS sr
USING (
  SELECT 
    id,
    name,
    city,
    CASE WHEN rating = '--' THEN '0.0' ELSE rating END AS rating,
    rating_count,
    cost,
    cuisine,
    CASE WHEN lic_no = 'license' THEN '00000000000000' ELSE lic_no END AS lic_no,
    link,
    address,
    menu
  FROM PRJ2.silver_layer.restaurants_stream_silver
) AS rb
ON rb.id = sr.id
WHEN MATCHED THEN
  UPDATE SET   
    sr.id = rb.id,
    sr.name = rb.name,
    sr.city = rb.city,
    sr.rating = rb.rating,
    sr.rating_count = rb.rating_count,
    sr.cost = rb.cost,
    sr.cuisine = rb.cuisine,
    sr.lic_no = rb.lic_no,
    sr.link = rb.link,
    sr.address = rb.address,
    sr.menu = rb.menu 
WHEN NOT MATCHED THEN
  INSERT (id, name, city, rating, rating_count, cost, cuisine, lic_no, link, address, menu) 
  VALUES (rb.id, rb.name, rb.city, rb.rating, rb.rating_count, rb.cost, rb.cuisine, rb.lic_no, rb.link, rb.address, rb.menu);

--activate the task
ALTER TASK restaurants_curated_task_gold RESUME;

SELECT * 
  FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
  where database_name = 'PRJ2' and schema_name = 'GOLD_LAYER'
  ORDER BY SCHEDULED_TIME;


