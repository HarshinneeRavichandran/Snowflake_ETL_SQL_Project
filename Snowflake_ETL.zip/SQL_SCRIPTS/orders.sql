use database PRJ2;

use schema bronze_layer;

create  or replace table orders(
    order_id varchar,
    order_date varchar,
    sales_qty varchar,
    sales_amount varchar,
    currency varchar,
    user_id varchar,
    r_id varchar
);

create or replace stage orders_stage
FILE_FORMAT =  (FORMAT_NAME = PRJ2.BRONZE_LAYER.MY_CSV_FORMAT);

create or replace pipe orders_ingest_pipe
as 
    copy into PRJ2.BRONZE_LAYER.ORDERS
    from @PRJ2.BRONZE_LAYER.ORDERS_STAGE
    FILE_FORMAT =  (FORMAT_NAME = 'PRJ2.BRONZE_LAYER.MY_CSV_FORMAT');


create or replace stream  orders_stream_bronze on table orders
append_only = true;-- show_initial_rows = true;

select count(*) from PRJ2.BRONZE_LAYER.orders; ---150281
select count(*) from PRJ2.BRONZE_LAYER.orders; ---150286

select system$pipe_status('PRJ2.BRONZE_LAYER.orders_INGEST_PIPE'); ---checks status 
call system$pipe_force_resume('PRJ2.BRONZE_LAYER.orders_INGEST_PIPE'); --- only loaded the newly added files from stage 
alter pipe PRJ2.BRONZE_LAYER.orders_INGEST_PIPE refresh;

SELECT * FROM snowflake.account_usage.copy_history
WHERE table_name = 'orders' and TABLE_CATALOG_NAME = 'PRJ2'
LIMIT 10;

select * from PRJ2.BRONZE_LAYER.orders_STREAM_BRONZE;

-----------------------------------------------------------------------------

---silver layer 


use schema PRJ2.silver_layer;

create or replace table silver_orders(
    order_date date,
    sales_qty integer,
    sales_amount integer,
    currency varchar,
    user_id integer,
    r_id float
) ;

CREATE OR replace TASK PRJ2.silver_layer.orders_curated_task
WAREHOUSE = COMPUTE_WH
SCHEDULE = '1 minutes'
AS
MERGE INTO PRJ2.silver_layer.silver_orders AS so
USING PRJ2.bronze_layer.orders_stream_bronze AS ob
ON ob.user_id = so.user_id
WHEN MATCHED THEN
  UPDATE SET so.order_date = ob.order_date,
so.sales_qty = ob.sales_qty,
so.sales_amount = ob.sales_amount,
so.currency = ob.currency,
so.user_id = ob.user_id,
so.r_id = ob.r_id 
WHEN NOT MATCHED THEN
  INSERT (order_date,
sales_qty,
sales_amount,
currency,
user_id,
r_id ) VALUES ( ob.order_date,
 ob.sales_qty,
 ob.sales_amount,
 ob.currency,
 ob.user_id,
 ob.r_id );
 
--activate the task
ALTER TASK orders_curated_task RESUME;

select count(*) from PRJ2.SILVER_LAYER.SILVER_orders; ---150281
select count(*) from PRJ2.SILVER_LAYER.SILVER_orders; ---150286

SELECT * 
  FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
  where database_name = 'PRJ2'
  ORDER BY SCHEDULED_TIME;


  --------------------------------------------------------------------------------------
  --gold layer la we will create streams and tasks 
use schema PRJ2.silver_layer;

create or replace stream  orders_stream_silver on table SILVER_ORDERS
append_only = true;-- show_initial_rows = true;


use schema PRJ2.gold_layer;

select * from PRJ2.gold_layer.order_fact;
select * from  PRJ2.silver_layer.orders_stream_silver;

CREATE OR REPLACE TASK PRJ2.gold_layer.orders_curated_task_gold
WAREHOUSE = COMPUTE_WH
SCHEDULE = '1 minutes'
AS
MERGE INTO PRJ2.gold_layer.order_fact AS so
USING PRJ2.silver_layer.orders_stream_silver AS ob
ON ob.user_id = so.user_id
WHEN MATCHED THEN
  UPDATE SET so.order_date = ob.order_date,
so.sales_qty = ob.sales_qty,
so.sales_amount = ob.sales_amount,
so.currency = ob.currency,
so.user_id = ob.user_id,
so.r_id = ob.r_id 
WHEN NOT MATCHED THEN
  INSERT (order_date,
sales_qty,
sales_amount,
currency,
user_id,
r_id ) VALUES ( ob.order_date,
 ob.sales_qty,
 ob.sales_amount,
 ob.currency,
 ob.user_id,
 ob.r_id );

--activate the task
ALTER TASK orders_curated_task_gold RESUME;

SELECT * 
  FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
  where database_name = 'PRJ2' and schema_name = 'GOLD_LAYER'
  ORDER BY SCHEDULED_TIME;
