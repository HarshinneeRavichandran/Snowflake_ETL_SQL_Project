use database PRJ2;

use schema bronze_layer;

create  or replace table items(
    ud varchar,
    menu_id varchar,
    r_id varchar,
    f_id varchar,
    cuisine varchar,
    price varchar
);

CREATE or replace FILE FORMAT MY_CSV_FORMAT
TYPE = 'CSV'
FIELD_DELIMITER = ',' 
FIELD_OPTIONALLY_ENCLOSED_BY = '"'
COMPRESSION = 'AUTO'
skip_header = 1
error_on_column_count_mismatch=false;

create or replace stage items_stage
FILE_FORMAT =  (FORMAT_NAME = PRJ2.BRONZE_LAYER.MY_CSV_FORMAT);

create or replace pipe items_ingest_pipe
as 
    copy into PRJ2.BRONZE_LAYER.items
    from @PRJ2.BRONZE_LAYER.items_STAGE
    FILE_FORMAT =  (FORMAT_NAME = 'PRJ2.BRONZE_LAYER.MY_CSV_FORMAT');


create or replace stream  items_stream_bronze on table items
append_only = true;-- show_initial_rows = true;

select count(*) from PRJ2.BRONZE_LAYER.items; ---1179936
select count(*) from PRJ2.BRONZE_LAYER.items; ---1179941

select system$pipe_status('PRJ2.BRONZE_LAYER.items_INGEST_PIPE'); ---checks status 
call system$pipe_force_resume('PRJ2.BRONZE_LAYER.items_INGEST_PIPE'); --- only loaded the newly added files from stage 
alter pipe PRJ2.BRONZE_LAYER.items_INGEST_PIPE refresh;

SELECT * FROM snowflake.account_usage.copy_history
WHERE table_name = 'items' and TABLE_CATALOG_NAME = 'PRJ2'
LIMIT 10;

select * from PRJ2.BRONZE_LAYER.items_STREAM_BRONZE;

-----------------------------------------------------------------------------

---silver layer 


use schema PRJ2.silver_layer;

create or replace table silver_items(
    menu_id varchar,
    r_id integer,
    f_id varchar,
    cuisine varchar,
    price varchar
) ;

CREATE OR replace TASK PRJ2.silver_layer.items_curated_task
WAREHOUSE = COMPUTE_WH
SCHEDULE = '1 minutes'
AS
MERGE INTO PRJ2.silver_layer.silver_items AS si
USING PRJ2.bronze_layer.items_stream_bronze AS ib
ON ib.menu_id = si.menu_id
WHEN MATCHED THEN
  UPDATE SET si.menu_id=ib.menu_id,
si.r_id=ib.r_id,
si.f_id=ib.f_id,
si.cuisine=ib.cuisine,
si.price=ib.price 
WHEN NOT MATCHED THEN
  INSERT (menu_id,
r_id,
f_id,
cuisine,
price) VALUES ( ib.menu_id,
ib.r_id,
ib.f_id,
ib.cuisine,
ib.price );
 
--activate the task
ALTER TASK items_curated_task RESUME;

select count(*) from PRJ2.SILVER_LAYER.SILVER_items; ---1179936
select count(*) from PRJ2.SILVER_LAYER.SILVER_items; ---1179941

SELECT * 
  FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
  where database_name = 'PRJ2'
  ORDER BY SCHEDULED_TIME;


    --------------------------------------------------------------------------------------
  --gold layer la we will create streams and tasks 
use schema PRJ2.silver_layer;

create or replace stream  items_stream_silver on table SILVER_ITEMS
append_only = true;-- show_initial_rows = true;


use schema PRJ2.gold_layer;

select * from PRJ2.gold_layer.items_dim;
select * from  PRJ2.silver_layer.items_stream_silver;

CREATE OR replace TASK PRJ2.gold_layer.items_curated_task_gold
WAREHOUSE = COMPUTE_WH
SCHEDULE = '1 minutes'
AS
MERGE INTO PRJ2.gold_layer.items_dim AS si
USING PRJ2.silver_layer.items_stream_silver AS ib
ON ib.menu_id = si.menu_id
WHEN MATCHED THEN
  UPDATE SET si.menu_id=ib.menu_id,
si.r_id=ib.r_id,
si.f_id=ib.f_id,
si.cuisine=ib.cuisine,
si.price=ib.price 
WHEN NOT MATCHED THEN
  INSERT (menu_id,
r_id,
f_id,
cuisine,
price) VALUES ( ib.menu_id,
ib.r_id,
ib.f_id,
ib.cuisine,
ib.price );

--activate the task
ALTER TASK items_curated_task_gold RESUME;

SELECT * 
  FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
  where database_name = 'PRJ2' and schema_name = 'GOLD_LAYER'
  ORDER BY SCHEDULED_TIME;

