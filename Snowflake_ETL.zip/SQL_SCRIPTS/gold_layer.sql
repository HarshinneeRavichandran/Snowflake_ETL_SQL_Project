use database PRJ2;
use schema GOLD_LAYER;

create or replace table customer_dim(
    user_id integer,
    name varchar,
    email varchar,
    password varchar,
    Age integer,
    Gender varchar
    --Marital_Status varchar,
    --Occupation varchar,
    --Monthly_Income varchar,
   -- Educational_Qualifications varchar,
    --Family_size integer
)  comment ='this is customers table with in gold layer';

insert into customer_dim(
    user_id ,
    name ,
    email ,
    password ,
    Age ,
    Gender 
) select 
    user_id ,
    name ,
    email ,
    password ,
    Age ,
    Gender from PRJ2.SILVER_LAYER.SILVER_CUSTOMER;

select * from PRJ2.GOLD_LAYER.CUSTOMER_DIM;
select count(*) from PRJ2.GOLD_LAYER.CUSTOMER_DIM; --100004


--------------------------------------------------------------------

create or replace table items_dim(
    menu_id varchar,
    r_id integer,
    f_id varchar,
    cuisine varchar,
    price varchar,
    item varchar,
    veg_or_non_veg varchar
)  comment ='this is items table with in gold layer';

insert into items_dim(
    menu_id ,
    r_id ,
    f_id ,
    cuisine,
    price,
    item,
    veg_or_non_veg 
) select 
    si.menu_id ,
    si.r_id ,
    si.f_id ,
    si.cuisine,
    sf.item ,
    sf.veg_or_non_veg,
    si.price from PRJ2.SILVER_LAYER.SILVER_ITEMS si
    inner join PRJ2.SILVER_LAYER.SILVER_FOOD sf on sf.f_id = si.f_id;

select * from PRJ2.GOLD_LAYER.ITEMS_DIM;
select count(*) from PRJ2.GOLD_LAYER.ITEMS_DIM;  --1179936
--------------------------------------------------------------------------
create or replace table order_fact(
 order_date date,
    sales_qty integer,
    sales_amount integer,
    currency varchar,
    user_id integer,
    r_id float
)comment = 'this order data is oresent in gold layer';

insert into order_fact(
order_date ,
    sales_qty ,
    sales_amount ,
    currency ,
    user_id ,
    r_id 
) select 
 order_date ,
    sales_qty ,
    sales_amount ,
    currency ,
    user_id ,
    r_id from PRJ2.SILVER_LAYER.SILVER_ORDERS;

select * from PRJ2.GOLD_LAYER.ORDER_FACT;
select count(*) from PRJ2.GOLD_LAYER.ORDER_FACT; --150282
-----------------------------------------------------------

create or replace table restaurants_dim(
    id integer,
    name varchar,
    city varchar,
    rating float,
    rating_count varchar,
    cost varchar,
    cuisine varchar,
    lic_no varchar,
    link varchar,
    address varchar,
    menu varchar
);

insert into restaurants_dim(
id ,
    name,
    city,
    rating ,
    rating_count ,
    cost ,
    cuisine ,
    lic_no ,
    link ,
    address ,
    menu
)select 
    id ,
    name,
    city,
    rating ,
    rating_count ,
    cost ,
    cuisine ,
    lic_no ,
    link ,
    address ,
    menu from PRJ2.SILVER_LAYER.SILVER_RESTAURANTS;

select * from restaurants_dim;
select count(*) from restaurants_dim;   --148545

