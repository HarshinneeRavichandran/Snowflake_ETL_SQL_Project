use database PRJ2;

use schema bronze_layer;

create  or replace table food(
    food_id varchar,
    f_id varchar,
    item varchar,
    veg_or_non_veg varchar
);

CREATE or replace FILE FORMAT MY_CSV_FORMAT
TYPE = 'CSV'
FIELD_DELIMITER = ',' 
FIELD_OPTIONALLY_ENCLOSED_BY = '"'
COMPRESSION = 'AUTO'
skip_header = 1
error_on_column_count_mismatch=false;

create or replace stage food_stage
FILE_FORMAT =  (FORMAT_NAME = PRJ2.BRONZE_LAYER.MY_CSV_FORMAT);

create or replace pipe food_ingest_pipe
as 
    copy into PRJ2.BRONZE_LAYER.food
    from @PRJ2.BRONZE_LAYER.food_STAGE
    FILE_FORMAT =  (FORMAT_NAME = 'PRJ2.BRONZE_LAYER.MY_CSV_FORMAT');


create or replace stream  food_stream_bronze on table food
append_only = true;-- show_initial_rows = true;

select count(*) from PRJ2.BRONZE_LAYER.food; ---371561
select count(*) from PRJ2.BRONZE_LAYER.food; ---371566

select system$pipe_status('PRJ2.BRONZE_LAYER.food_INGEST_PIPE'); ---checks status 
call system$pipe_force_resume('PRJ2.BRONZE_LAYER.food_INGEST_PIPE'); --- only loaded the newly added files from stage 
alter pipe PRJ2.BRONZE_LAYER.food_INGEST_PIPE refresh;

SELECT * FROM snowflake.account_usage.copy_history
WHERE table_name = 'food' and TABLE_CATALOG_NAME = 'PRJ2'
LIMIT 10;

select * from PRJ2.BRONZE_LAYER.food_STREAM_BRONZE;

-----------------------------------------------------------------------------

---silver layer 


use schema PRJ2.silver_layer;

create or replace table silver_food(
    f_id varchar,
    item varchar,
    veg_or_non_veg varchar
) ;

CREATE OR replace TASK PRJ2.silver_layer.food_curated_task
WAREHOUSE = COMPUTE_WH
SCHEDULE = '1 minutes'
AS
MERGE INTO PRJ2.silver_layer.silver_food AS sf
USING PRJ2.bronze_layer.food_stream_bronze AS fb
ON fb.f_id = sf.f_id
WHEN MATCHED THEN
  UPDATE SET sf.f_id= fb.f_id,
sf.item= fb.item,
sf.veg_or_non_veg= fb.veg_or_non_veg 
WHEN NOT MATCHED THEN
  INSERT (f_id,
item,
veg_or_non_veg) VALUES (  fb.f_id,
 fb.item,
 fb.veg_or_non_veg );
 
--activate the task
ALTER TASK food_curated_task RESUME;

select count(*) from PRJ2.SILVER_LAYER.SILVER_food; ---371561
select count(*) from PRJ2.SILVER_LAYER.SILVER_food; --- 371566

SELECT * 
  FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
  where database_name = 'PRJ2'
  ORDER BY SCHEDULED_TIME;
