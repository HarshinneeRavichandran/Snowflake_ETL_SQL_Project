create database PRJ2;

create schema bronze_layer;

create table customer(
    index_value varchar,
    user_id varchar,
    name varchar,
    email varchar,
    password varchar,
    Age varchar,
    Gender varchar,
    Marital_Status varchar,
    Occupation varchar,
    Monthly_Income varchar,
    Educational_Qualifications varchar,
    Family_size varchar
);

CREATE or replace FILE FORMAT my_csv_format
TYPE = 'CSV'
FIELD_DELIMITER = ','
COMPRESSION = 'AUTO'
skip_header = 1
error_on_column_count_mismatch=false;


create or replace stage customer_stage
FILE_FORMAT =  (FORMAT_NAME = PRJ2.BRONZE_LAYER.MY_CSV_FORMAT);

create or replace pipe customer_ingest_pipe
as 
    copy into PRJ2.BRONZE_LAYER.CUSTOMER
    from @PRJ2.BRONZE_LAYER.CUSTOMER_STAGE
    FILE_FORMAT =  (FORMAT_NAME = 'PRJ2.BRONZE_LAYER.MY_CSV_FORMAT');

/*CREATE OR REPLACE TASK PRJ2.BRONZE_LAYER.Delete_customer_stage_task
WAREHOUSE = COMPUTE_WH
SCHEDULE = '3 minutes'
AFTER PRJ2.BRONZE_LAYER.CUSTOMER_INGEST_PIPE
AS
BEGIN   -- Clear the stream
        remove  @PRJ2.BRONZE_LAYER.CUSTOMER_STAGE;
        RETURN 'Files removed successfully';

END;*/

create or replace stream  customer_stream_bronze on table CUSTOMER
append_only = true;-- show_initial_rows = true;

select count(*) from PRJ2.BRONZE_LAYER.CUSTOMER; ---100000


select system$pipe_status('PRJ2.BRONZE_LAYER.CUSTOMER_INGEST_PIPE'); ---checks status 
call system$pipe_force_resume('PRJ2.BRONZE_LAYER.CUSTOMER_INGEST_PIPE'); --- only loaded the newly added files from stage 
alter pipe PRJ2.BRONZE_LAYER.CUSTOMER_INGEST_PIPE refresh;

SELECT * FROM snowflake.account_usage.copy_history
WHERE table_name = 'CUSTOMER' and TABLE_CATALOG_NAME = 'PRJ2'
--ORDER BY last_load_time DESC 
LIMIT 10;

select * from PRJ2.BRONZE_LAYER.CUSTOMER_STREAM_BRONZE;

-----------------------------------------------------------------------------

---silver layer 

create schema PRJ2.silver_layer;
use schema PRJ2.silver_layer;

create or replace table silver_customer(
    user_id integer,
    name varchar,
    email varchar,
    password varchar,
    Age integer,
    Gender varchar,
    Marital_Status varchar,
    Occupation varchar,
    Monthly_Income varchar,
    Educational_Qualifications varchar,
    Family_size integer
) ;

CREATE OR REPLACE TASK PRJ2.silver_layer.customer_curated_task
WAREHOUSE = COMPUTE_WH
SCHEDULE = '1 minutes'
AS
MERGE INTO PRJ2.silver_layer.silver_customer AS c
USING PRJ2.bronze_layer.customer_stream_bronze AS cs
ON cs.user_id = c.user_id
WHEN MATCHED THEN
  UPDATE SET c.user_id = cs.user_id ,
c.name = cs.name ,
c.email = cs.email ,
c.password = cs.password ,
c.Age = cs.Age ,
c.Gender = cs.Gender ,
c.Marital_Status = cs.Marital_Status ,
c.Occupation = cs.Occupation ,
c.Monthly_Income = cs.Monthly_Income ,
c.Educational_Qualifications = cs.Educational_Qualifications ,
c.Family_size = cs.Family_size 
WHEN NOT MATCHED THEN
  INSERT (user_id ,
name ,
email ,
password ,
Age ,
Gender ,
Marital_Status ,
Occupation ,
Monthly_Income ,
Educational_Qualifications ,
Family_size ) VALUES (cs.user_id ,
cs.name ,
cs.email ,
cs.password ,
cs.Age ,
cs.Gender ,
cs.Marital_Status ,
cs.Occupation ,
cs.Monthly_Income ,
cs.Educational_Qualifications ,
cs.Family_size );

--activate the task
ALTER TASK customer_curated_task RESUME;

select count(*) from PRJ2.SILVER_LAYER.SILVER_CUSTOMER; ---- 100000



SELECT * 
  FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
  where database_name = 'PRJ2'
  ORDER BY SCHEDULED_TIME;

----------------------------------------------------------------------
--gold layer la we will create streams and tasks 
use schema PRJ2.silver_layer;

create or replace stream  customer_stream_silver on table SILVER_CUSTOMER
append_only = true;-- show_initial_rows = true;


use schema PRJ2.gold_layer;


CREATE OR REPLACE TASK PRJ2.gold_layer.customer_curated_task_gold
WAREHOUSE = COMPUTE_WH
SCHEDULE = '1 minutes'
AS
MERGE INTO PRJ2.gold_layer.customer_dim AS cd
USING PRJ2.silver_layer.customer_stream_silver AS cs
ON cs.user_id = cd.user_id
WHEN MATCHED THEN
  UPDATE SET cd.user_id = cs.user_id ,
cd.name = cs.name ,
cd.email = cs.email ,
cd.password = cs.password ,
cd.Age = cs.Age ,
cd.Gender = cs.Gender 
WHEN NOT MATCHED THEN
  INSERT (user_id ,
name ,
email ,
password ,
Age ,
Gender 
 ) VALUES (cs.user_id ,
cs.name ,
cs.email ,
cs.password ,
cs.Age ,
cs.Gender 
 );

--activate the task
ALTER TASK customer_curated_task_gold RESUME;

SELECT * 
  FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
  where database_name = 'PRJ2' and schema_name = 'GOLD_LAYER'
  ORDER BY SCHEDULED_TIME;







